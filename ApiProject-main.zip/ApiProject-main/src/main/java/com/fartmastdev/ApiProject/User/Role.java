package com.fartmastdev.ApiProject.User;

public enum Role {
    ADMIN,
    USER  
}
